function checkMail(){
  const email = document.getElementById("email").value();

  console.log(email);
}
